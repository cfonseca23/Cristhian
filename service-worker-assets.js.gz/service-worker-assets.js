﻿self.assetsManifest = {
  "assets": [
    {
      "hash": "sha256-L0ApgkZaJxawVcfuyph13NN5HgcJsR65gJwSISTwLvU=",
      "url": "css\/app.css"
    },
    {
      "hash": "sha256-rldnE7wZYJj3Q43t5v8fg1ojKRwyt0Wtfm+224CacZs=",
      "url": "css\/bootstrap\/bootstrap.min.css"
    },
    {
      "hash": "sha256-xMZ0SaSBYZSHVjFdZTAT\/IjRExRIxSriWcJLcA9nkj0=",
      "url": "css\/bootstrap\/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-jA4J4h\/k76zVxbFKEaWwFKJccmO0voOQ1DbUW+5YNlI=",
      "url": "css\/open-iconic\/FONT-LICENSE"
    },
    {
      "hash": "sha256-BJ\/G+e+y7bQdrYkS2RBTyNfBHpA9IuGaPmf9htub5MQ=",
      "url": "css\/open-iconic\/font\/css\/open-iconic-bootstrap.min.css"
    },
    {
      "hash": "sha256-OK3poGPgzKI2NzNgP07XMbJa3Dz6USoUh\/chSkSvQpc=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.eot"
    },
    {
      "hash": "sha256-sDUtuZAEzWZyv\/U1xl\/9D3ehyU69JE+FvAcu5HQ+\/a0=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.otf"
    },
    {
      "hash": "sha256-+P1oQ5jPzOVJGC52E1oxGXIXxxCyMlqy6A9cNxGYzVk=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.svg"
    },
    {
      "hash": "sha256-p+RP8CV3vRK1YbIkNzq3rPo1jyETPnR07ULb+HVYL8w=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.ttf"
    },
    {
      "hash": "sha256-cZPqVlRJfSNW0KaQ4+UPOXZ\/v\/QzXlejRDwUNdZIofI=",
      "url": "css\/open-iconic\/font\/fonts\/open-iconic.woff"
    },
    {
      "hash": "sha256-aF5g\/izareSj02F3MPSoTGNbcMBl9nmZKDe04zjU\/ss=",
      "url": "css\/open-iconic\/ICON-LICENSE"
    },
    {
      "hash": "sha256-p\/oxU91iBE+uaDr3kYOyZPuulf4YcPAMNIz6PRA\/tb0=",
      "url": "css\/open-iconic\/README.md"
    },
    {
      "hash": "sha256-Jtxf9L+5ITKRc1gIRl4VbUpGkRNfOBXjYTdhJD4facM=",
      "url": "favicon-1.ico"
    },
    {
      "hash": "sha256-bCzE0LAJAJEZnKNF+DSMvMvGg0jvGN3RsBpusTb\/hdQ=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-eGhpLILc+S8\/HLknJULLhSpmcmpxiUTAty\/EE9ZHitw=",
      "url": "icon-512-programming.png"
    },
    {
      "hash": "sha256-IpHFcQvs03lh6W54zoeJRG1jW+VnGmwymzxLoXtKX7Y=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Aon1kVpUnafUqGNcaaW3AVVmZN2N2i2uv1WCbfZHG5s=",
      "url": "index.html"
    },
    {
      "hash": "sha256-zbtHuJg9Lx2JR5XOazX\/eBPRpCnINEAfuEb0j9H6VlY=",
      "url": "manifest.json"
    },
    {
      "hash": "sha256-yzFf+O\/mlH+Q9klUSqXP2kxGKOUFLPxaww8da8fKhGU=",
      "url": "sample-data\/weather.json"
    },
    {
      "hash": "sha256-7w8yLgolT9mK58A8DN4p3fA1wWdGB+8RS++q3tPXs70=",
      "url": "_framework\/Microsoft.CSharp.dll"
    },
    {
      "hash": "sha256-V1KpCFevupHZe1+dWpJW33HjUVBWKJoGe7VLVRvSAfg=",
      "url": "_framework\/Microsoft.VisualBasic.Core.dll"
    },
    {
      "hash": "sha256-vmR3u+TDpPtHZ4XOdjyxQ2ST6N2z9QaK1FNRSSE0l2w=",
      "url": "_framework\/Microsoft.VisualBasic.dll"
    },
    {
      "hash": "sha256-UyXCWIWYFQFGFbsEL+nfeI+pbCiIYL7HkIaM7GSscuA=",
      "url": "_framework\/Microsoft.Win32.Primitives.dll"
    },
    {
      "hash": "sha256-1iZTfRN6oC+8\/BkrCh3PgiR6yTWizNOvrV19XBaV1aM=",
      "url": "_framework\/Microsoft.Win32.Registry.dll"
    },
    {
      "hash": "sha256-T1s2vDPnAu\/jLrl2cjk4D\/dE0cRDxL9rzryz2e\/NP5M=",
      "url": "_framework\/System.AppContext.dll"
    },
    {
      "hash": "sha256-jKZDYpWTdQ\/N\/7VwyNevKlwTO9uBJiL9xeFB9a0ggL8=",
      "url": "_framework\/System.Buffers.dll"
    },
    {
      "hash": "sha256-W4FCPYBNUh12zGt9fZDKwv25EGyzkvzq7EVpLUsG4qM=",
      "url": "_framework\/System.Collections.Concurrent.dll"
    },
    {
      "hash": "sha256-BZSWQ0aDE7US5XsXMRVkFitngPNRY8FOUPHdJKlEUCQ=",
      "url": "_framework\/System.Collections.Immutable.dll"
    },
    {
      "hash": "sha256-\/MXL64lVq4NbUgW2tyh\/5xD1yoD9wmqI76tBuBq79EY=",
      "url": "_framework\/System.Collections.NonGeneric.dll"
    },
    {
      "hash": "sha256-\/4WftFUZtMvuImIRmLSRroXoi2roMmn6sVKjbzJWlVc=",
      "url": "_framework\/System.Collections.Specialized.dll"
    },
    {
      "hash": "sha256-iBQqzjxWJjW9sRUq5ku8ET6rG15+Xlrj2qW8D1sDeCU=",
      "url": "_framework\/System.Collections.dll"
    },
    {
      "hash": "sha256-G25JyeN+yvNR0AH1TlMmlfYXaj5arAvs749HkCS9nXc=",
      "url": "_framework\/System.ComponentModel.Annotations.dll"
    },
    {
      "hash": "sha256-On94q5BiIwrdcnImlpJ\/Djey51U+YGiqUD68DS\/j6lg=",
      "url": "_framework\/System.ComponentModel.DataAnnotations.dll"
    },
    {
      "hash": "sha256-H9x6nhigZBl52tN1yzU+R\/Chi+DfkjokMhLvqAKu10U=",
      "url": "_framework\/System.ComponentModel.EventBasedAsync.dll"
    },
    {
      "hash": "sha256-Kl2vHU6WQDKQaO\/1Zgihi2Nu754ppU2EKUytoQJBf40=",
      "url": "_framework\/System.ComponentModel.Primitives.dll"
    },
    {
      "hash": "sha256-jaPYS1GWYbs\/rUrcrsM8k1DunHCWALenubBhgS8P89s=",
      "url": "_framework\/System.ComponentModel.TypeConverter.dll"
    },
    {
      "hash": "sha256-5HYZ26az+jKfiIeSDktGrF9a\/V0czmyGdOAeX5WXZJg=",
      "url": "_framework\/System.ComponentModel.dll"
    },
    {
      "hash": "sha256-oBpCwzeLZR\/Ty4SeFR3V58Fvjpx1dTPdaUQmLpjUD48=",
      "url": "_framework\/System.Configuration.dll"
    },
    {
      "hash": "sha256-H4ig3SOmfpWwGJaD6rUHNYgktrDqHvhHHTMdtkBN02Y=",
      "url": "_framework\/System.Console.dll"
    },
    {
      "hash": "sha256-IrE66twJEDTlFwXLVghTKftn\/KQI1TW\/5HoQAVoj7w4=",
      "url": "_framework\/System.Core.dll"
    },
    {
      "hash": "sha256-p9Yuv46KJE5H2xuRxECsYtP6JhmQXEkb2GrhTWkQjhc=",
      "url": "_framework\/System.Data.Common.dll"
    },
    {
      "hash": "sha256-pFRMO0Ylkw3BYalmTz8p\/a0CVC\/P05e5C\/ZBJxWVpxs=",
      "url": "_framework\/System.Data.DataSetExtensions.dll"
    },
    {
      "hash": "sha256-mt3eBOybIm2Zx0RHfM7cs5UbT2lcVxigBeCggUh9Oak=",
      "url": "_framework\/System.Data.dll"
    },
    {
      "hash": "sha256-jv6bzAMF+uTMGzWnZMBl4TXavV6XgoNECBJw847yPJc=",
      "url": "_framework\/System.Diagnostics.Contracts.dll"
    },
    {
      "hash": "sha256-OL6oBCVIRrUQJLM2jsnmlwm+wi0Nq2Eg2F5arxrY8jM=",
      "url": "_framework\/System.Diagnostics.Debug.dll"
    },
    {
      "hash": "sha256-ROAMBlDh2EvYqSQeXqkm3Xf3\/E8A2hYolm+qluIc+Eg=",
      "url": "_framework\/System.Diagnostics.DiagnosticSource.dll"
    },
    {
      "hash": "sha256-+P9xnT5k4rZ1OFetYTBvU1ifeQsn7a4E3wONEBgKCTM=",
      "url": "_framework\/System.Diagnostics.FileVersionInfo.dll"
    },
    {
      "hash": "sha256-IA9HE1URRLIB+zyaItf1ZMDuS1Wn2bAjv5vSy\/fx7eI=",
      "url": "_framework\/System.Diagnostics.Process.dll"
    },
    {
      "hash": "sha256-V7OGFTc9lwQXHMhcSjW2BvuEUHa4emuq3rFs9hRlJ3E=",
      "url": "_framework\/System.Diagnostics.StackTrace.dll"
    },
    {
      "hash": "sha256-wXQvNwG2LRjBs1MSpvlgu\/SC480WGZN\/2UPkuPjCkkw=",
      "url": "_framework\/System.Diagnostics.TextWriterTraceListener.dll"
    },
    {
      "hash": "sha256-wtW9dMqmLvXfgummpmJPNpfym+GMJKQ5AVkn8k2wlUY=",
      "url": "_framework\/System.Diagnostics.Tools.dll"
    },
    {
      "hash": "sha256-knSIIarxqjHc5qwezm7JqnSYBCQmRjqI9Qwb5bGuLAU=",
      "url": "_framework\/System.Diagnostics.TraceSource.dll"
    },
    {
      "hash": "sha256-CFr+khLjGao9kG1gM1ngmW\/bA+Jp9rUQ2LcU52sIV48=",
      "url": "_framework\/System.Diagnostics.Tracing.dll"
    },
    {
      "hash": "sha256-AWjQMFgudqL+elLVq98BtC\/CSHljc6O1orrcUSOYLS0=",
      "url": "_framework\/System.Drawing.Primitives.dll"
    },
    {
      "hash": "sha256-6x7NFHplFUXLXx59Qm+J2RzBKgb4Qh6hmrAt1DOWOzE=",
      "url": "_framework\/System.Drawing.dll"
    },
    {
      "hash": "sha256-srbmMmRA59rh\/qEJ7IRvX1Awsw8SzvFpVBMsC1AEg1Y=",
      "url": "_framework\/System.Dynamic.Runtime.dll"
    },
    {
      "hash": "sha256-Y\/\/4j0gMY7BxbU5d+z6W7b+y\/JrzZyGhxIT+qXdjnqE=",
      "url": "_framework\/System.Formats.Asn1.dll"
    },
    {
      "hash": "sha256-zD7Xj4nnlblqSwTr12eJJjVPxypWOdGgPH0j89q5fCI=",
      "url": "_framework\/System.Globalization.Calendars.dll"
    },
    {
      "hash": "sha256-Qh7RpE6AE5KT7Vfna2XBE\/7kBTHFgOHcDBhb11G+eEY=",
      "url": "_framework\/System.Globalization.Extensions.dll"
    },
    {
      "hash": "sha256-5uwdqRCz7X031169c3PjDGhPSaIlSaMA9CbGOAI0Crw=",
      "url": "_framework\/System.Globalization.dll"
    },
    {
      "hash": "sha256-PbDaLwqkUpP+tpgPjMDteRBKcqzIgs0my9uQ5VcrBV4=",
      "url": "_framework\/System.IO.Compression.Brotli.dll"
    },
    {
      "hash": "sha256-m41UqMj4Hi5k3cdUx+TwH2AVAXFgZ1dre9MdtjJINOQ=",
      "url": "_framework\/System.IO.Compression.FileSystem.dll"
    },
    {
      "hash": "sha256-fH1R3jjm\/+8gZAhrZD62XRc+pdpbwOtYyEeaYlGdYOA=",
      "url": "_framework\/System.IO.Compression.ZipFile.dll"
    },
    {
      "hash": "sha256-PV0xtAOguTCmgXA9ot7KL\/qLr4su30x2DSpquZ7wRRc=",
      "url": "_framework\/System.IO.Compression.dll"
    },
    {
      "hash": "sha256-AewnkmPDMxbAMw3XKJs8RTCrWPu8gfN492d9B\/+7JRA=",
      "url": "_framework\/System.IO.FileSystem.AccessControl.dll"
    },
    {
      "hash": "sha256-ZvLjIoEpaYoB6yW\/dqIbjIRwmknPYYYlMp5mhyUMYnE=",
      "url": "_framework\/System.IO.FileSystem.DriveInfo.dll"
    },
    {
      "hash": "sha256-HKntkE7enpQT3IBXIvBLavRyK8t14I6PxpfHRxK8MfA=",
      "url": "_framework\/System.IO.FileSystem.Primitives.dll"
    },
    {
      "hash": "sha256-db897GwUBe8vxefuz9bGlW6mWFyB8n5Bk\/Mux0ccRrc=",
      "url": "_framework\/System.IO.FileSystem.Watcher.dll"
    },
    {
      "hash": "sha256-0sLKNq4gK2hstdu3mV4rcwCRZCOOXgZIt5aTmaDiZ34=",
      "url": "_framework\/System.IO.FileSystem.dll"
    },
    {
      "hash": "sha256-ivaFU6qwlhnoUy92SumM8ZnpY\/kXjcUGJSBtNbHBzhY=",
      "url": "_framework\/System.IO.IsolatedStorage.dll"
    },
    {
      "hash": "sha256-mBWuXOX1z9YWkv6uLcNLAe8TAAhj0NaBlstX7cDV+3Y=",
      "url": "_framework\/System.IO.MemoryMappedFiles.dll"
    },
    {
      "hash": "sha256-URnaMfSfPOdjTV\/bFHkBLI9bXAAgHEoyF83SGQGwnTU=",
      "url": "_framework\/System.IO.Pipes.AccessControl.dll"
    },
    {
      "hash": "sha256-lcIIg6eV32n9vi7QPsJXMs279co2KHeT1KEWbguQuvg=",
      "url": "_framework\/System.IO.Pipes.dll"
    },
    {
      "hash": "sha256-huXss+tPF6izVbd7yS3x1yOWdMYRNe9UMYWlRIk+m7c=",
      "url": "_framework\/System.IO.UnmanagedMemoryStream.dll"
    },
    {
      "hash": "sha256-pIjugUhUdNZTUhurvqfEeeucW+HNi1FyOlV9zU8hpNs=",
      "url": "_framework\/System.IO.dll"
    },
    {
      "hash": "sha256-gJbGvSAppIUsmcioysXsSeBjXUjOYofMHdjfNlKx1Dk=",
      "url": "_framework\/System.Linq.Expressions.dll"
    },
    {
      "hash": "sha256-XZg41GMcjplxGNfAjvsY1plTum83qLBsjOAeehxoSPY=",
      "url": "_framework\/System.Linq.Parallel.dll"
    },
    {
      "hash": "sha256-PLaQ\/CJUaHAxc9z2pVxcGlg6ce8Q7AK8FzMRIVYgf+E=",
      "url": "_framework\/System.Linq.Queryable.dll"
    },
    {
      "hash": "sha256-BGiMedVJXwYjACwZOo6QaCWlJyRbTdQzVcKOgzRfS6g=",
      "url": "_framework\/System.Linq.dll"
    },
    {
      "hash": "sha256-7VhZp3snh0geL0w3yQdd0lt7CrMwi9+9fj3cRiYidko=",
      "url": "_framework\/System.Memory.dll"
    },
    {
      "hash": "sha256-xkWIiTprGeZ8QR3C84kTcufuOlN7LJglMDwOatkph1Q=",
      "url": "_framework\/System.Net.Http.Json.dll"
    },
    {
      "hash": "sha256-rlfo6REqqDHZHPsYETYYyazrzYdOwC9k+Gp1Hk38MZg=",
      "url": "_framework\/System.Net.Http.dll"
    },
    {
      "hash": "sha256-mtIjKpv0iy\/OsHvgDZYiXLXP9x2yvtffSF4BRZ5Axxg=",
      "url": "_framework\/System.Net.HttpListener.dll"
    },
    {
      "hash": "sha256-elI\/AAbXofP\/FyKJrOP+0vrSfugbsKTg9N79M7mG2hU=",
      "url": "_framework\/System.Net.Mail.dll"
    },
    {
      "hash": "sha256-AkM+NJNgoroNwALt4wnpVay5rYPrGVxKryWpY6aei0E=",
      "url": "_framework\/System.Net.NameResolution.dll"
    },
    {
      "hash": "sha256-g7VjMfHegn0P7YXVhvEaumgoy8PrfkmII0QzWhzEuLY=",
      "url": "_framework\/System.Net.NetworkInformation.dll"
    },
    {
      "hash": "sha256-ADSiNGz9c5CI1ksKwVCrrHGLU7dzg1upnpy3Inj7ttI=",
      "url": "_framework\/System.Net.Ping.dll"
    },
    {
      "hash": "sha256-eTaASe5T\/\/7V\/\/n1o+A3HVARlr52NdL4xiCLpENLouM=",
      "url": "_framework\/System.Net.Primitives.dll"
    },
    {
      "hash": "sha256-+YpgNtUETMajfqbykBgq\/Q3fOIV9mm3Tkm8kLgNP+Rw=",
      "url": "_framework\/System.Net.Requests.dll"
    },
    {
      "hash": "sha256-RCumeDe8PJo8ruaDBib6rpwDLRZFbSo3GGFGMrAJPY4=",
      "url": "_framework\/System.Net.Security.dll"
    },
    {
      "hash": "sha256-H552I2USEWLCXgm4mR7PtPUETVdN5UKXnAKx+yaHUBU=",
      "url": "_framework\/System.Net.ServicePoint.dll"
    },
    {
      "hash": "sha256-WHc4ZD76Xsbierm71NObtePUFjv9Wk73TlRBXssXAGY=",
      "url": "_framework\/System.Net.Sockets.dll"
    },
    {
      "hash": "sha256-xYFUh9+AHq7FVlj2LIC5r\/cEvyyynccJwXY7t\/+DYVk=",
      "url": "_framework\/System.Net.WebClient.dll"
    },
    {
      "hash": "sha256-zz0dPBUQU2jbSLdcWuxt+TyOHU9O0ouWchA57qFFSeY=",
      "url": "_framework\/System.Net.WebHeaderCollection.dll"
    },
    {
      "hash": "sha256-f0DWet\/Ouh\/i1c++bXwWQMdV\/TdEX6pPxa1dhToI5tU=",
      "url": "_framework\/System.Net.WebProxy.dll"
    },
    {
      "hash": "sha256-8COyQ4KoZkob19BnYR3GnYquLyGBzHEkQdfhW5qigo4=",
      "url": "_framework\/System.Net.WebSockets.Client.dll"
    },
    {
      "hash": "sha256-Mv7NdnP2JTR9oYN\/0BjGe9DT7ccHEhCJECDUitpH7Yo=",
      "url": "_framework\/System.Net.WebSockets.dll"
    },
    {
      "hash": "sha256-ulcwUpiNqs4d1CW12\/7nYtauoUuVZiBszuzZAtbuwQM=",
      "url": "_framework\/System.Net.dll"
    },
    {
      "hash": "sha256-puT2XLIvMo8bRX13rKum+12aF3IfZAn5NSy7\/cmyyTw=",
      "url": "_framework\/System.Numerics.Vectors.dll"
    },
    {
      "hash": "sha256-+YtieoMILRcKxYkNDsOCWyDMsB\/ZciBwjH1i0QvGjlc=",
      "url": "_framework\/System.Numerics.dll"
    },
    {
      "hash": "sha256-hZXUsPsdHcWqGX7yOLhSIXDiMZIciMfh0Z9EF+ykELs=",
      "url": "_framework\/System.ObjectModel.dll"
    },
    {
      "hash": "sha256-Uti5pjdYBdwp7TmiNHQvirSE89w7PXTYldIyjG9HUzI=",
      "url": "_framework\/System.Private.DataContractSerialization.dll"
    },
    {
      "hash": "sha256-agaF0Mgipipy9BH4\/lyy27RS77yZerY41+9082+Kivg=",
      "url": "_framework\/System.Private.Runtime.InteropServices.JavaScript.dll"
    },
    {
      "hash": "sha256-ABlJtoyhIGpVfeumRY0Bq9dgTEMtGH1QQBDAtfSWiA8=",
      "url": "_framework\/System.Private.Uri.dll"
    },
    {
      "hash": "sha256-jgV\/jRt53JE7Wp7V5Tjh\/x2+XuU1V8nd7II3zBQsnkE=",
      "url": "_framework\/System.Private.Xml.Linq.dll"
    },
    {
      "hash": "sha256-lO76dpPVWbg47MMyOHKzT29QJUqMjsqgrZMGU2YOF8E=",
      "url": "_framework\/System.Private.Xml.dll"
    },
    {
      "hash": "sha256-68m2\/cfh7Ep4i1K0GxyZCxhLlrdYyc\/gq5JkGCAQA0g=",
      "url": "_framework\/System.Reflection.DispatchProxy.dll"
    },
    {
      "hash": "sha256-5jw\/L38E8wN\/YnLzsFJQZZx86f\/JpU1LrGTO\/zDyLwY=",
      "url": "_framework\/System.Reflection.Emit.ILGeneration.dll"
    },
    {
      "hash": "sha256-vxDFiXnA0MOuJPSOAUmFCRpUmfd3hUYxWh9k2NWBcLM=",
      "url": "_framework\/System.Reflection.Emit.Lightweight.dll"
    },
    {
      "hash": "sha256-FDHlncUGpfT9CJRkcBKsn5+RO1XbMKHjpDDOHfwfC6A=",
      "url": "_framework\/System.Reflection.Emit.dll"
    },
    {
      "hash": "sha256-iOEz0Z\/i\/eYtUnT7q\/gPiB33MZldzJ9H4DLceqtVeV4=",
      "url": "_framework\/System.Reflection.Extensions.dll"
    },
    {
      "hash": "sha256-8f7VMg+43f7rsy3rEaa20OGzuTx\/JkvWLgG9fcC+Yp4=",
      "url": "_framework\/System.Reflection.Metadata.dll"
    },
    {
      "hash": "sha256-SsLqzYSvN9rnql7r+vqSdA+sDCmO6yjMXaGw3rvLBxs=",
      "url": "_framework\/System.Reflection.Primitives.dll"
    },
    {
      "hash": "sha256-o+PSqgEJ2+ZBUExR6GbJdwH9RTU6EVSpwJOYHbrgK+4=",
      "url": "_framework\/System.Reflection.TypeExtensions.dll"
    },
    {
      "hash": "sha256-UXoOX78ByttNXuIFCaBQMnYtNemweRxSc0Zw6vm5aiE=",
      "url": "_framework\/System.Reflection.dll"
    },
    {
      "hash": "sha256-+WU8K\/e06lH6hU\/NkjKpNebAXUrQmlh0XVvo\/ZJEvDo=",
      "url": "_framework\/System.Resources.Reader.dll"
    },
    {
      "hash": "sha256-Gj5vX0hhTlgo4uDHuur4710jQGQEh3hT1GJHlDeajRw=",
      "url": "_framework\/System.Resources.ResourceManager.dll"
    },
    {
      "hash": "sha256-HaVb8Ww6zkSN4DVwiZgyV4bRvw3aXanlk1duST3tC90=",
      "url": "_framework\/System.Resources.Writer.dll"
    },
    {
      "hash": "sha256-hPor52wjEmM7ROSTMQZQawnpqhgyF7ZHJcbnYcxpl9M=",
      "url": "_framework\/System.Runtime.CompilerServices.Unsafe.dll"
    },
    {
      "hash": "sha256-LV4hRmn3h\/l9sxgZ9OdHjV3OyV\/WNFgeJ7JB5+yAcf0=",
      "url": "_framework\/System.Runtime.CompilerServices.VisualC.dll"
    },
    {
      "hash": "sha256-NamgosMPN0E90nlPO43TMy0+m5g6FtFtrPHCS\/zD6k8=",
      "url": "_framework\/System.Runtime.Extensions.dll"
    },
    {
      "hash": "sha256-9mBkJPjfu5RtQPqYv1gbVrzSD6sVaF\/IeJlf\/YPzW1s=",
      "url": "_framework\/System.Runtime.Handles.dll"
    },
    {
      "hash": "sha256-eZu48CRE02hIzSBHp+A3MKgneW2K1qtROBS034l4fz0=",
      "url": "_framework\/System.Runtime.InteropServices.RuntimeInformation.dll"
    },
    {
      "hash": "sha256-pacgU\/4yaaUDYG7Bj\/I7rD\/dDEcA1t4lJhFWadfUfc4=",
      "url": "_framework\/System.Runtime.InteropServices.dll"
    },
    {
      "hash": "sha256-EIubXs+jwvfAuW7b7DSx+4nHntQUnqRibTn0MI2gZUM=",
      "url": "_framework\/System.Runtime.Intrinsics.dll"
    },
    {
      "hash": "sha256-feTafhFdBu8Rf\/\/pe2yCX6pgFaVu219E5Ua1arAouzw=",
      "url": "_framework\/System.Runtime.Loader.dll"
    },
    {
      "hash": "sha256-ZGMEHpch5JUooVoYIQYzK0WnIEvpF0jK7Bnioxc40p8=",
      "url": "_framework\/System.Runtime.Numerics.dll"
    },
    {
      "hash": "sha256-oQ7QaoIfnme0i3v3adT9YNfHjCjUnX0AL1ILXGpJMg8=",
      "url": "_framework\/System.Runtime.Serialization.Formatters.dll"
    },
    {
      "hash": "sha256-xsGId25SHOEClhU8NjhcddMzZA4fGxItqKOBgIswPVg=",
      "url": "_framework\/System.Runtime.Serialization.Json.dll"
    },
    {
      "hash": "sha256-nPHtlQShCG680P0YKK6b5\/TKrCDEeORi0VPbWuVCHms=",
      "url": "_framework\/System.Runtime.Serialization.Primitives.dll"
    },
    {
      "hash": "sha256-SNVJrNA3WNo7VPQwtLDf5X69mRj9UxfilKUDM2FbsYs=",
      "url": "_framework\/System.Runtime.Serialization.Xml.dll"
    },
    {
      "hash": "sha256-F9\/s4DlFzWgH7uohHb2XcN+LKkrDjm3wHvSOEu1yL8o=",
      "url": "_framework\/System.Runtime.Serialization.dll"
    },
    {
      "hash": "sha256-UJRSrUGdfuZZtOscCu3JLE4sHmQCj5sg2FJ0j3y6CS0=",
      "url": "_framework\/System.Runtime.dll"
    },
    {
      "hash": "sha256-iodT3UB3klpE5nAm92Jxu4ymk8g1hvcmM\/jEk2RaJR0=",
      "url": "_framework\/System.Security.AccessControl.dll"
    },
    {
      "hash": "sha256-DqLLLermSF95iPyZGFHSTtc7l6xqwV2mslL0h0kcMyc=",
      "url": "_framework\/System.Security.Claims.dll"
    },
    {
      "hash": "sha256-KkbstFXtHMh\/5icdkoIsEXd73nXwP17Na\/reDQ6HYYc=",
      "url": "_framework\/System.Security.Cryptography.Algorithms.dll"
    },
    {
      "hash": "sha256-FbauHpLCSiUccJFbcWbkXJbZkNmvMhvQ1H1mggmoNuk=",
      "url": "_framework\/System.Security.Cryptography.Cng.dll"
    },
    {
      "hash": "sha256-eNAGD97T72x3tA6aW9oHytkBALDQEA1xIHZPOP7pkj8=",
      "url": "_framework\/System.Security.Cryptography.Csp.dll"
    },
    {
      "hash": "sha256-qz4ciomocXF0nFQO7FDWgzfINIw3bjdUB1yC9or4hVk=",
      "url": "_framework\/System.Security.Cryptography.Encoding.dll"
    },
    {
      "hash": "sha256-GqHuSJsTGUJ+HiytZhKrdQqAxown2pIWkMcQrCNmpQM=",
      "url": "_framework\/System.Security.Cryptography.OpenSsl.dll"
    },
    {
      "hash": "sha256-0BIi+dU06FI0DIOVYcIK68gtZlR2rzKoaMpLPZItWL4=",
      "url": "_framework\/System.Security.Cryptography.Primitives.dll"
    },
    {
      "hash": "sha256-ZO59LegUDnYOdRCtg9ye+Sk1pgdMs33yzTXNwGlZpc4=",
      "url": "_framework\/System.Security.Cryptography.X509Certificates.dll"
    },
    {
      "hash": "sha256-u20aSIBjhIKpvZ4Ly5oXXmtYh9FreNCWv8bmqAZYPcQ=",
      "url": "_framework\/System.Security.Principal.Windows.dll"
    },
    {
      "hash": "sha256-fq6aju8CCHsIE5FdvwXAegINVQoy6DNwEArT7KZI4r0=",
      "url": "_framework\/System.Security.Principal.dll"
    },
    {
      "hash": "sha256-fFWhxnUbOUqTYIa1bcC8Lbuh2KM2H1C+la+De5\/0A+4=",
      "url": "_framework\/System.Security.SecureString.dll"
    },
    {
      "hash": "sha256-AtcX5+WNK+UW6U2XuJG95zexOiETv3yUooKsqQG24KY=",
      "url": "_framework\/System.Security.dll"
    },
    {
      "hash": "sha256-ivULpCyI5Mghkphk53E9n00Iz7vUsCjWCli5wPUzYKc=",
      "url": "_framework\/System.ServiceModel.Web.dll"
    },
    {
      "hash": "sha256-M+B6j9SZSmHB1N\/Kc1EDKF8n5HBZwcZNj8Cqvue3yHY=",
      "url": "_framework\/System.ServiceProcess.dll"
    },
    {
      "hash": "sha256-OeI1ppOAPWORFd5tD3ttBIAAvwwP7Z1695RQ70LfvaQ=",
      "url": "_framework\/System.Text.Encoding.CodePages.dll"
    },
    {
      "hash": "sha256-203VKqmxJrHHDcHrTZihGtf3Ug2BG25DvAXpHllWQxY=",
      "url": "_framework\/System.Text.Encoding.Extensions.dll"
    },
    {
      "hash": "sha256-HhShQ4jfNKChkTpoGAgtBg5sgwndJg0TIGsINzzDLp0=",
      "url": "_framework\/System.Text.Encoding.dll"
    },
    {
      "hash": "sha256-9Ap18meAdaiMK5AGmNSme3DutyyTvXtSDbDNd8r2NrM=",
      "url": "_framework\/System.Text.Encodings.Web.dll"
    },
    {
      "hash": "sha256-0Kn8I0CNVjZJecmhKROwtuiTHpGG6QL9Uzq2jn26eTA=",
      "url": "_framework\/System.Text.Json.dll"
    },
    {
      "hash": "sha256-T9vDkESzQNNu3KOs+h9dQi5Vp9uZUw2CjuVktXzKHAM=",
      "url": "_framework\/System.Text.RegularExpressions.dll"
    },
    {
      "hash": "sha256-lgV9GYgskigNcqQ2qLgtCNONf8ZSp+BHEvxLEMy69Xg=",
      "url": "_framework\/System.Threading.Channels.dll"
    },
    {
      "hash": "sha256-FtXv+1dFXLz+xPP3G3f9EEVFg7vBsxwF4dFki8hWJ94=",
      "url": "_framework\/System.Threading.Overlapped.dll"
    },
    {
      "hash": "sha256-AwTJSSl42uwV+73Y\/851pgcZFS25Mj9pdV4uR2ajqL0=",
      "url": "_framework\/System.Threading.Tasks.Dataflow.dll"
    },
    {
      "hash": "sha256-fNF7AkyJQttZv8xA0P0Y90kRRnHl6VwgDphgMAvsQto=",
      "url": "_framework\/System.Threading.Tasks.Extensions.dll"
    },
    {
      "hash": "sha256-S3yqKb8ePYxn+LmZitpPmZmut+JQ\/LZoSvglGzr5f6A=",
      "url": "_framework\/System.Threading.Tasks.Parallel.dll"
    },
    {
      "hash": "sha256-JQhOecmjQVcj8KObWWTcL5lYisjSCQg3sGfhcGYSdJY=",
      "url": "_framework\/System.Threading.Tasks.dll"
    },
    {
      "hash": "sha256-+5Ngg4kdcgLSr7\/Xkt5DYvpDFeiDSsKXIvZnrmgVzzw=",
      "url": "_framework\/System.Threading.Thread.dll"
    },
    {
      "hash": "sha256-9ONglojGGMsmNgaXP0Vb1X9+3O95Fzl0id63mM7Gums=",
      "url": "_framework\/System.Threading.ThreadPool.dll"
    },
    {
      "hash": "sha256-6m2o5F2bclsnoMSAT2biO2dyHMm0gvir549lbqyECcY=",
      "url": "_framework\/System.Threading.Timer.dll"
    },
    {
      "hash": "sha256-mV9TxwuTGTsCmPk8mqN05s3onwiTWMYauK+FG6MGcX8=",
      "url": "_framework\/System.Threading.dll"
    },
    {
      "hash": "sha256-IWlzkh\/9jn3ah+6N0UxuO1lC5ufUn5DYvngVF5526bw=",
      "url": "_framework\/System.Transactions.Local.dll"
    },
    {
      "hash": "sha256-e8J+IMtnz7AJjn1gtS5S2w\/eNs+A7nWVLrn2jxJ4eOY=",
      "url": "_framework\/System.Transactions.dll"
    },
    {
      "hash": "sha256-MDOK3RncHymQuefQrgqiOXOE48xO\/JteVXezPz49NE4=",
      "url": "_framework\/System.ValueTuple.dll"
    },
    {
      "hash": "sha256-YCF2rlS41RruWRqlY\/0f9bdaaKEMzB\/sXvjwwWrSokI=",
      "url": "_framework\/System.Web.HttpUtility.dll"
    },
    {
      "hash": "sha256-x3409kW9wB5iqXRkp7za0iLlPNeG7R3rz+vZoVl28xE=",
      "url": "_framework\/System.Web.dll"
    },
    {
      "hash": "sha256-r5+\/QNIfCPhDsgEUgM5QZ3z7M3yz5GURXgpLMxHPOnc=",
      "url": "_framework\/System.Windows.dll"
    },
    {
      "hash": "sha256-AVa9YqLa2Wm6PvzSq47IBrCt9n186oeLrxCuCsdZkiw=",
      "url": "_framework\/System.Xml.Linq.dll"
    },
    {
      "hash": "sha256-akJT2K7yNL7jqFuIy7GQYQhNbnTe1h0IgcYKjhkiE9s=",
      "url": "_framework\/System.Xml.ReaderWriter.dll"
    },
    {
      "hash": "sha256-l360QgndgWwk0aWeirzHTYh6wwVp1dx6BU1LK3iaFTg=",
      "url": "_framework\/System.Xml.Serialization.dll"
    },
    {
      "hash": "sha256-iKvyJ55DNhSfHwIXP745kAxi9xLmJEQClKADhvGj+JY=",
      "url": "_framework\/System.Xml.XDocument.dll"
    },
    {
      "hash": "sha256-\/dYHqpMx9GoKHiWSjFP\/4M8lGYlHulacPZAAa8KeYLw=",
      "url": "_framework\/System.Xml.XPath.XDocument.dll"
    },
    {
      "hash": "sha256-JDc14eFvADPupdhyVR6502ae4UgGN\/YQiTxEi1oYtsc=",
      "url": "_framework\/System.Xml.XPath.dll"
    },
    {
      "hash": "sha256-p9jY22oWSGc1gtRVLoMC3bGWXybeqvqR41zRuyK+9g8=",
      "url": "_framework\/System.Xml.XmlDocument.dll"
    },
    {
      "hash": "sha256-dcLO5IIXZxdTUbRHl7dAmFCtLTpTxjhod\/A2ZrMV1Pk=",
      "url": "_framework\/System.Xml.XmlSerializer.dll"
    },
    {
      "hash": "sha256-03Bz2HSkeF9+V7eymGL+XNL6QzdzC5vXuwCuXlhiKrU=",
      "url": "_framework\/System.Xml.dll"
    },
    {
      "hash": "sha256-sVwd7kNQm2g+8OKVzqJjz+viDy0m5wZsLAvtOFlPDnE=",
      "url": "_framework\/System.dll"
    },
    {
      "hash": "sha256-Ndg0utNbTcXOzM+mq84JqS\/qlsO22pwF2UxTZDifn7o=",
      "url": "_framework\/WindowsBase.dll"
    },
    {
      "hash": "sha256-Fi+LybwHL\/VGD\/09OxxtYlT6exn9xVU+LdojZ9juR2c=",
      "url": "_framework\/mscorlib.dll"
    },
    {
      "hash": "sha256-P8xX0ad1hKyWWbBxiXl3cYokFlDiuXwp3pqoYatH0kk=",
      "url": "_framework\/netstandard.dll"
    },
    {
      "hash": "sha256-2km83sNUTrumGJYdDzsN8RnJqv00vKWLCCh0UGajTB4=",
      "url": "_framework\/System.Private.CoreLib.dll"
    },
    {
      "hash": "sha256-ibxaSjW7s3aLVssChknhzCpgMTHGu4D48Q9OLP3dfe8=",
      "url": "_framework\/dotnet.timezones.blat"
    },
    {
      "hash": "sha256-+NqBIg7FTMeA2q0mxzbehfuE2WPrnq53yqLsu47afbY=",
      "url": "_framework\/dotnet.wasm"
    },
    {
      "hash": "sha256-m7NyeXyxM+CL04jr9ui1Z6pVfMWwhHusuz5qNZWpAwA=",
      "url": "_framework\/icudt.dat"
    },
    {
      "hash": "sha256-91bygK5voY9lG5wxP0\/uj7uH5xljF9u7iWnSldT1Z\/g=",
      "url": "_framework\/icudt_CJK.dat"
    },
    {
      "hash": "sha256-DPfeOLph83b2rdx40cKxIBcfVZ8abTWAFq+RBQMxGw0=",
      "url": "_framework\/icudt_EFIGS.dat"
    },
    {
      "hash": "sha256-oM7Z6aN9jHmCYqDMCBwFgFAYAGgsH1jLC\/Z6DYeVmmk=",
      "url": "_framework\/icudt_no_CJK.dat"
    },
    {
      "hash": "sha256-VR9AaflChiwC+KUJnKHaZAMWHeF8tQ1Giwr7XsIRIfw=",
      "url": "_framework\/dotnet.5.0.4.js"
    },
    {
      "hash": "sha256-RW0auaJ5JlrPXA4\/PQLL4xfSx6Ig+MVi0cvrb4vc4vY=",
      "url": "cf-Perfil.styles.css"
    },
    {
      "hash": "sha256-gsPUK5MPEytu+GgZXlgPHPCiAQm8jaWpvW\/hcvd1vt0=",
      "url": "_framework\/Microsoft.AspNetCore.Components.dll"
    },
    {
      "hash": "sha256-7FxjWdh\/48T0UIZkWYl1JEx1DbVmnUfG6FlDuZVUprI=",
      "url": "_framework\/Microsoft.AspNetCore.Components.Web.dll"
    },
    {
      "hash": "sha256-MOjc1UXg4gX8KJ8UdswRwScj0H2khgJg7m4JB\/Pe6P8=",
      "url": "_framework\/Microsoft.AspNetCore.Components.WebAssembly.dll"
    },
    {
      "hash": "sha256-R6lgTmWZQPc8zEQZSIkTb6Cw6TRDR9DlssL\/q1fTG4g=",
      "url": "_framework\/Microsoft.Extensions.Configuration.dll"
    },
    {
      "hash": "sha256-F9I+0e7EyaafnAUWdWoVvklWg1Fj5AQpEpDvLA9WQ7U=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Abstractions.dll"
    },
    {
      "hash": "sha256-DcTOo9gXOu6Rpr8D85aQmt5KRX\/v1xwAZLlldyUHK3E=",
      "url": "_framework\/Microsoft.Extensions.Configuration.Json.dll"
    },
    {
      "hash": "sha256-sFLIXlNE+1rsIVDR7vHabGMLsLCzlNOaBgPZSlix\/bc=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.dll"
    },
    {
      "hash": "sha256-nFOzP2WKCWLDJkaeR8scIWbsDRPdHVZc6uCoIgYwLgY=",
      "url": "_framework\/Microsoft.Extensions.DependencyInjection.Abstractions.dll"
    },
    {
      "hash": "sha256-ItVqY6H2CkoU21V\/k6WwyVs553TJsixjYW08mF43mn4=",
      "url": "_framework\/Microsoft.Extensions.Logging.dll"
    },
    {
      "hash": "sha256-1qMpq0WGanfSymZ7G9G2miVo\/3nU28VSxiJkuAkU6m4=",
      "url": "_framework\/Microsoft.Extensions.Logging.Abstractions.dll"
    },
    {
      "hash": "sha256-G+pRSzA7e8kfyDv69bfOqUSGBuMfM+PsRIetL71fwd4=",
      "url": "_framework\/Microsoft.Extensions.Options.dll"
    },
    {
      "hash": "sha256-vpj6p5lL2M+GsRVAI+VVi3I\/dpflkVJLcloOS52D\/\/8=",
      "url": "_framework\/Microsoft.Extensions.Primitives.dll"
    },
    {
      "hash": "sha256-114c7Kng5wf2dRo39ix9XLd9gu\/uEVko0oqnNohR3rA=",
      "url": "_framework\/Microsoft.JSInterop.dll"
    },
    {
      "hash": "sha256-YlYt1zT1hT+aqQZN29dDxRiK4W\/IlVEC3wpLUTx9jtY=",
      "url": "_framework\/Microsoft.JSInterop.WebAssembly.dll"
    },
    {
      "hash": "sha256-3ET+mpR7F058YRj9YaLHOVXBqOW6iUxtIpeiKPYw4PA=",
      "url": "_framework\/System.IO.Pipelines.dll"
    },
    {
      "hash": "sha256-\/k6Xi78qN6P21Tp1mRL5a5sOWbmKFo73XpYAi0o0bOQ=",
      "url": "_framework\/cf-Perfil.dll"
    },
    {
      "hash": "sha256-fWURTvfAX93SXuzXiAQLT7CZk7WxT77qR3HblFicsrM=",
      "url": "_framework\/blazor.boot.json"
    },
    {
      "hash": "sha256-dl8FVRvWOJfOtzIC\/x66QNnBNsT9cAOMrn22GB8fJ8U=",
      "url": "_framework\/blazor.webassembly.js"
    }
  ],
  "version": "MrW4t8zB"
};
